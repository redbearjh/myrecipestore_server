module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl' : 'mongodb://localhost:27017/myRecipeStore',
    'facebook': {
        clientID: 'YOUR FACEBOOK APP ID',
        clientSecret: 'YOUR FACEBOOK SECRET',
        callbackURL: 'https://localhost:3443/users/facebook/callback'
    }
}